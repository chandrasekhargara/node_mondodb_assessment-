import express from "express";
import userController from "../controllers/userController"; // ✅ Import default export

const { createUser, getUsers, updateUser, deleteUser } = userController;

const router = express.Router();

router.post("/users", createUser);
router.get("/users", getUsers);
router.put("/users/:id", updateUser);
router.delete("/users/:id", deleteUser);

export default router;
