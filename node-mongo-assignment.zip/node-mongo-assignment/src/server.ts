import express from "express";
import dotenv from "dotenv";
import cors from "cors";
import bodyParser from "body-parser";
import connectDB from "./config/db";
import userRoutes from "./routes/userRoutes.js";

console.log("🔄 Starting server...");

dotenv.config();
console.log("✅ Environment variables loaded");

connectDB();
console.log("✅ Database connection function called");

const app = express();
app.use(cors());
app.use(bodyParser.json());
console.log("✅ Middleware configured");

app.use("/api", userRoutes);
console.log("✅ User routes added");

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
