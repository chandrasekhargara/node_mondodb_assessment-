"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const User_js_1 = __importDefault(require("../models/User.js"));
const createUser = async (req, res) => {
    try {
        const user = await User_js_1.default.create(req.body);
        res.status(201).json(user);
    }
    catch (error) {
        res.status(400).json({ error: "Error creating user" });
    }
};
const getUsers = async (req, res) => {
    const users = await User_js_1.default.find();
    res.json(users);
};
const updateUser = async (req, res) => {
    const user = await User_js_1.default.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(user);
};
const deleteUser = async (req, res) => {
    await User_js_1.default.findByIdAndDelete(req.params.id);
    res.json({ message: "User deleted successfully" });
};
exports.default = { createUser, getUsers, updateUser, deleteUser }; // ✅ Default export
