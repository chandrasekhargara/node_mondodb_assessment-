"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const dotenv_1 = __importDefault(require("dotenv"));
const cors_1 = __importDefault(require("cors"));
const body_parser_1 = __importDefault(require("body-parser"));
const db_1 = __importDefault(require("./config/db"));
const userRoutes_js_1 = __importDefault(require("./routes/userRoutes.js"));
console.log("🔄 Starting server...");
dotenv_1.default.config();
console.log("✅ Environment variables loaded");
(0, db_1.default)();
console.log("✅ Database connection function called");
const app = (0, express_1.default)();
app.use((0, cors_1.default)());
app.use(body_parser_1.default.json());
console.log("✅ Middleware configured");
app.use("/api", userRoutes_js_1.default);
console.log("✅ User routes added");
// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
